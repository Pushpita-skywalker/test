Admin email   :admin.1993@northsouth.edu
Admin password:admin1993
Captcha image selection(image number): 1, 2, 6, 9

Student Email    :StudentName.StudentID@northsouth.edu
Student Password :StudentID

Example:

Student Email:Rafat.1234567@northsouth.edu
Student password:1234567